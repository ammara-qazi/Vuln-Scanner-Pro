# WebVulnScanner GUI

A browser-based (Flask) vulnerability scanner. Enter a target URL, watch it
crawl and test the site live, and get a severity-ranked findings report you
can download as JSON / TXT / HTML / Word (DOCX).

> ⚠️ **Authorized testing only.** Only scan systems you own or have explicit
> written permission to test — your own local DVWA / OWASP Juice Shop, or
> any target you've been given written authorization for. The app will not
> send a single request until you tick the ownership confirmation box.

---

## What it does

1. You enter a target URL and (optionally) a session cookie, crawl depth,
   request delay, and which checks to run.
2. On submit, the backend spins up a background scan job and the page shows
   a live **stage rail** (Crawl → Headers → Server Info → XSS → SQLi →
   Report) plus a scrolling log feed, polling the server every ~1.2s.
3. When done, you get a **severity-ranked findings list** in the browser,
   plus download links for JSON / TXT / HTML / Word (DOCX) reports.

Checks included:
- **Reflected XSS** — enhanced with multiple payloads (script, svg, img, javascript) to test different reflection contexts.
- **SQL Injection** — error-based (known DB error signatures) + boolean-based blind detection.
- **Open Redirect** — checks if parameters redirect the user to external domains.
- **Directory Listing** — checks common paths for exposed directory listings.
- **Missing security headers** — CSP, X-Frame-Options, HSTS, X-Content-Type-Options, Referrer-Policy, Permissions-Policy, plus cookie flag checks (Secure/HttpOnly/SameSite).
- **Server information disclosure** — Server/X-Powered-By headers, verbose stack-trace/error signatures in the response body.

---

## Project structure

```
WebVulnScanner_GUI/
├── app.py                 # Flask app: routes + background job runner
├── requirements.txt
├── core/
│   ├── http_client.py     # rate-limited requests.Session wrapper
│   ├── crawler.py         # BFS crawler -> pages, forms, params
│   ├── report_writer.py   # JSON/TXT/HTML report file generation
│   └── checks/
│       ├── xss.py
│       ├── sqli.py
│       ├── headers.py
│       ├── server_info.py
│       ├── directory_listing.py
│       └── open_redirect.py
├── templates/index.html   # single-page UI
├── static/css/style.css
├── static/js/app.js       # form submit, polling, results rendering
├── reports/                # generated report files land here (gitignored)
└── examples/               # put your DVWA/Juice Shop screenshots here
```

---

## Installation

Requires **Python 3.9+**.

```bash
cd WebVulnScanner_GUI
python3 -m venv venv
source venv/bin/activate        # Windows: venv\Scripts\activate
pip install -r requirements.txt
```

## Running it

```bash
python app.py
```

Then open **http://127.0.0.1:5000** in your browser.

## Usage

1. Paste your target URL (e.g. `http://localhost:3000/` for Juice Shop).
2. Open **Advanced options** if you want to change the delay, crawl depth,
   page limit, add a session cookie (for authenticated DVWA scans), or
   deselect a check.
3. Tick **"I own this target..."** — required, the scan button stays
   inactive without it.
4. Click **Run scan** and watch the stage rail progress.
5. Review findings inline, or download the JSON/TXT/HTML/Word (DOCX) report.

### Scanning DVWA (authenticated)

Log into DVWA in your browser, copy the `PHPSESSID` and `security` cookies
from DevTools → Application → Cookies, and paste them into the **Cookie**
field, e.g.:

```
PHPSESSID=abc123; security=low
```

> Set **DVWA Security Level → Low** first so unfiltered vulnerabilities are
> easy to demonstrate.

### Scanning OWASP Juice Shop

No cookie needed for most of its reflected-input bugs:

```
http://localhost:3000/
```

---

## How the "live" GUI works (for your own understanding)

- Submitting the form calls `POST /api/scan`, which validates the target +
  ownership confirmation, spins up a **background thread** running the scan,
  and immediately returns a `job_id` — the HTTP request doesn't block for
  the whole scan.
- The page then polls `GET /api/status/<job_id>` every 1.2 seconds, which
  returns the current stage/log lines. The **stage rail** is just a visual
  read of those log lines (see `guessStageFromText()` in `app.js`).
- Once `status == "done"`, the page calls `GET /api/result/<job_id>` for the
  full findings list, and `GET /api/report/<job_id>/<fmt>` generates/returns
  a downloadable file.
- Job data lives in an in-memory Python dict (`JOBS`) — fine for a single
  local user; a multi-user deployment would need a real job queue (Celery/RQ)
  and persistent storage instead.

---

## Limitations

Same as any lightweight scanner — see the CLI version's README for the full
list, in short: no JS rendering (static HTML crawl only), no stored XSS
across pages, no CSRF/business-logic checks, and false positives/negatives
are possible. Always verify findings manually.

## Legal / Ethical Notice

Provided for educational purposes and **authorized security testing only**.
Running active scans (XSS/SQLi payload injection) against systems you don't
own or don't have explicit permission to test may violate computer misuse
laws in your jurisdiction. The author(s) accept no liability for misuse.
