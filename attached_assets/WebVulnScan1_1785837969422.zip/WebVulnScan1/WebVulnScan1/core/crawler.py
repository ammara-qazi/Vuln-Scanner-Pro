"""
crawler.py
Same-origin, breadth-first crawler. Discovers internal links, HTML forms
(action/method/inputs), and URL query parameters.
"""
from collections import deque
from urllib.parse import urljoin, urlparse, parse_qs
from bs4 import BeautifulSoup


class Page:
    def __init__(self, url):
        self.url = url
        self.forms = []
        self.url_params = []

    def to_dict(self):
        return {"url": self.url, "forms": self.forms, "url_params": self.url_params}


def _same_scope(url, base_netloc):
    parsed = urlparse(url)
    return parsed.netloc == "" or parsed.netloc == base_netloc


def _extract_forms(soup, page_url):
    forms = []
    for form in soup.find_all("form"):
        action = form.get("action") or ""
        method = (form.get("method") or "get").lower()
        inputs = []
        for field in form.find_all(["input", "textarea", "select", "button"]):
            name = field.get("name")
            if not name:
                continue
            field_type = field.get("type", "text").lower()
            # We want to test hidden fields too as they are often vulnerable
            if field_type in ("submit", "reset", "file"):
                continue
            inputs.append({"name": name, "type": field_type})
        
        # If no action, it posts to the current URL
        full_action = urljoin(page_url, action)
        if inputs:
            forms.append({"action": full_action, "method": method, "inputs": inputs})
    return forms


class Crawler:
    def __init__(self, client, start_url, max_depth=2, max_pages=40, progress_cb=None):
        self.client = client
        self.start_url = start_url
        self.max_depth = max_depth
        self.max_pages = max_pages
        self.base_netloc = urlparse(start_url).netloc
        self.visited = set()
        self.pages = []
        self.progress_cb = progress_cb  # optional callable(message)

    def _report(self, msg):
        if self.progress_cb:
            self.progress_cb(msg)

    def crawl(self):
        queue = deque([(self.start_url, 0)])
        while queue and len(self.visited) < self.max_pages:
            url, depth = queue.popleft()
            norm = url.split("#")[0]
            if norm in self.visited or depth > self.max_depth:
                continue
            self.visited.add(norm)

            resp = self.client.get(norm)
            if resp is None or "text/html" not in resp.headers.get("Content-Type", ""):
                continue

            page = Page(norm)
            parsed = urlparse(norm)
            if parsed.query:
                page.url_params = list(parse_qs(parsed.query).keys())

            try:
                soup = BeautifulSoup(resp.text, "lxml")
            except Exception:
                soup = BeautifulSoup(resp.text, "html.parser")

            page.forms = _extract_forms(soup, norm)
            self.pages.append(page)
            self._report(f"Crawled {norm} ({len(page.forms)} forms, {len(page.url_params)} params)")

            if depth < self.max_depth:
                # Find links in <a>, <area>, <link>, <frame>, <iframe>
                for tag in soup.find_all(["a", "area", "link", "frame", "iframe"], href=True):
                    link = urljoin(norm, tag["href"]).split("#")[0]
                    if _same_scope(link, self.base_netloc) and link not in self.visited:
                        queue.append((link, depth + 1))
                
                # Also check src attributes in scripts/images for potential directory discovery
                for tag in soup.find_all(["script", "img", "embed", "source"], src=True):
                    link = urljoin(norm, tag["src"]).split("#")[0]
                    # Only follow if it looks like a page/directory, not a binary asset
                    if _same_scope(link, self.base_netloc) and link not in self.visited:
                        if any(link.endswith(ext) for ext in [".html", ".php", ".asp", ".aspx", "/"]):
                            queue.append((link, depth + 1))
        return self.pages
