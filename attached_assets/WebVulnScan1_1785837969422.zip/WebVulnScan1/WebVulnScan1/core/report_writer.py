"""report_writer.py - writes JSON/TXT/HTML report files for a finished job."""
import json
import datetime
from collections import Counter

SEVERITY_ORDER = {"Critical": 0, "High": 1, "Medium": 2, "Low": 3, "Info": 4}


def _sorted(findings):
    return sorted(findings, key=lambda f: SEVERITY_ORDER.get(f.get("severity", "Info"), 5))


# Public alias - other modules should use this rather than the "private" name.
sort_findings = _sorted


def write_json(path, target, findings, stats):
    findings = _sorted(findings)
    payload = {
        "target": target,
        "generated_at": datetime.datetime.now().isoformat(timespec="seconds"),
        "stats": stats,
        "finding_count": len(findings),
        "findings": findings,
    }
    with open(path, "w", encoding="utf-8") as fh:
        json.dump(payload, fh, indent=2)


def write_txt(path, target, findings, stats):
    findings = _sorted(findings)
    lines = [f"WebVulnScanner Report -- {target}",
              f"Generated: {datetime.datetime.now().isoformat(timespec='seconds')}",
              f"Pages crawled: {stats.get('pages_crawled', 0)} | "
              f"Requests sent: {stats.get('requests_sent', 0)} | Findings: {len(findings)}",
              "-" * 70]
    if not findings:
        lines.append("No issues detected by the checks that were run.")
    for i, f in enumerate(findings, 1):
        lines.append(f"\n[{i}] [{f['severity']}] {f['type']}")
        lines.append(f"    URL:         {f['url']}")
        lines.append(f"    Location:    {f['location']}")
        lines.append(f"    Description: {f['description']}")
        lines.append(f"    Evidence:    {f.get('evidence', 'n/a')}")
        lines.append(f"    Fix:         {f.get('recommendation', 'n/a')}")
    with open(path, "w", encoding="utf-8") as fh:
        fh.write("\n".join(lines))


HTML_TEMPLATE = """<!DOCTYPE html>
<html><head><meta charset="UTF-8"><title>WebVulnScanner Report - {target}</title>
<style>
body{{font-family:'IBM Plex Sans',Arial,sans-serif;background:#0B0E14;color:#E8EAED;margin:0}}
header{{padding:28px 36px;background:linear-gradient(135deg,#161B26,#0B0E14);border-bottom:1px solid #232838}}
h1{{margin:0 0 6px;font-size:22px}}
.meta{{color:#7B8494;font-size:13px}}
main{{padding:20px 36px 60px}}
.finding{{background:#12161F;border:1px solid #232838;border-left:4px solid #7B8494;border-radius:8px;padding:16px 20px;margin-bottom:14px}}
.finding.Critical{{border-left-color:#FF4365}} .finding.High{{border-left-color:#FF8A3D}}
.finding.Medium{{border-left-color:#FFC857}} .finding.Low{{border-left-color:#4FB0C6}}
.badge{{font-size:11px;text-transform:uppercase;padding:3px 10px;border-radius:12px;font-weight:700}}
.badge.Critical{{background:rgba(255,67,101,.15);color:#FF4365}} .badge.High{{background:rgba(255,138,61,.15);color:#FF8A3D}}
.badge.Medium{{background:rgba(255,200,87,.15);color:#FFC857}} .badge.Low{{background:rgba(79,176,198,.15);color:#4FB0C6}}
.row{{margin-top:8px;font-size:13.5px}} .label{{color:#7B8494;display:inline-block;min-width:100px}}
.mono{{font-family:'JetBrains Mono',monospace;font-size:12.5px;word-break:break-all}}
.evidence{{margin-top:8px;background:#0B0E14;border:1px solid #232838;border-radius:6px;padding:8px 12px;font-size:12.5px;color:#FFC857;word-break:break-all}}
</style></head><body>
<header><h1>WebVulnScanner Report</h1><div class="meta">Target: {target} &middot; Generated: {generated_at} &middot;
Pages: {pages} &middot; Requests: {requests} &middot; Findings: {count}</div></header>
<main>{body}</main></body></html>"""

FINDING_TEMPLATE = """<div class="finding {severity}">
<div style="display:flex;justify-content:space-between"><h3 style="margin:0;font-size:15px">{idx}. {type}</h3>
<span class="badge {severity}">{severity}</span></div>
<div class="row"><span class="label">URL</span><span class="mono">{url}</span></div>
<div class="row"><span class="label">Location</span><span class="mono">{location}</span></div>
<div class="row"><span class="label">Description</span>{description}</div>
<div class="row"><span class="label">Recommendation</span>{recommendation}</div>
<div class="evidence mono">{evidence}</div></div>"""


def _esc(s):
    return (str(s).replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;"))


def write_html(path, target, findings, stats):
    findings = _sorted(findings)
    if not findings:
        body = "<p style='color:#7B8494'>No issues detected by the checks that were run.</p>"
    else:
        body = "".join(FINDING_TEMPLATE.format(
            idx=i, type=_esc(f["type"]), severity=f["severity"], url=_esc(f["url"]),
            location=_esc(f["location"]), description=_esc(f["description"]),
            recommendation=_esc(f.get("recommendation", "n/a")), evidence=_esc(f.get("evidence", "n/a")),
        ) for i, f in enumerate(findings, 1))

    html = HTML_TEMPLATE.format(
        target=_esc(target), generated_at=datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        pages=stats.get("pages_crawled", 0), requests=stats.get("requests_sent", 0),
        count=len(findings), body=body,
    )
    with open(path, "w", encoding="utf-8") as fh:
        fh.write(html)


def _clean(s):
    """Remove control characters that break python-docx / XML."""
    if not isinstance(s, str):
        s = str(s)
    return "".join(ch for ch in s if ord(ch) >= 32 or ch in "\r\n\t")


def write_docx(path, target, findings, stats):
    from docx import Document
    from docx.shared import Pt, RGBColor
    from docx.enum.text import WD_ALIGN_PARAGRAPH

    findings = _sorted(findings)
    doc = Document()

    # Title
    title = doc.add_heading("WebVulnScanner Security Report", 0)
    title.alignment = WD_ALIGN_PARAGRAPH.CENTER

    # Summary Info
    doc.add_heading("Scan Summary", level=1)
    table = doc.add_table(rows=4, cols=2)
    table.style = "Table Grid"
    summary_data = [
        ("Target URL", _clean(target)),
        ("Scan Date", datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")),
        ("Pages Crawled", str(stats.get("pages_crawled", 0))),
        ("Total Findings", str(len(findings))),
    ]
    for i, (label, value) in enumerate(summary_data):
        table.cell(i, 0).text = _clean(label)
        table.cell(i, 1).text = _clean(value)

    # Severity Breakdown
    doc.add_heading("Findings by Severity", level=2)
    sev_counts = severity_summary(findings)
    sev_table = doc.add_table(rows=1, cols=len(sev_counts))
    sev_table.style = "Table Grid"
    for i, (sev, count) in enumerate(sev_counts.items()):
        cell = sev_table.cell(0, i)
        cell.text = _clean(f"{sev}: {count}")

    # Findings Detail
    doc.add_heading("Detailed Findings", level=1)
    if not findings:
        doc.add_paragraph("No vulnerabilities were identified during this scan.")
    else:
        for i, f in enumerate(findings, 1):
            doc.add_heading(_clean(f"{i}. {f['type']}"), level=2)
            
            p = doc.add_paragraph()
            p.add_run("Severity: ").bold = True
            sev_run = p.add_run(_clean(f["severity"]))
            if f["severity"] == "Critical":
                sev_run.font.color.rgb = RGBColor(255, 0, 0)
            elif f["severity"] == "High":
                sev_run.font.color.rgb = RGBColor(255, 165, 0)

            p = doc.add_paragraph()
            p.add_run("URL: ").bold = True
            p.add_run(_clean(f["url"]))

            p = doc.add_paragraph()
            p.add_run("Location: ").bold = True
            p.add_run(_clean(f["location"]))

            doc.add_heading("Description", level=3)
            doc.add_paragraph(_clean(f["description"]))

            doc.add_heading("Evidence", level=3)
            doc.add_paragraph(_clean(f.get("evidence", "n/a")), style="No Spacing")

            doc.add_heading("Recommendation", level=3)
            doc.add_paragraph(_clean(f.get("recommendation", "n/a")))
            
            doc.add_page_break()

    doc.save(path)


def severity_summary(findings):
    counts = Counter(f["severity"] for f in findings)
    return {sev: counts.get(sev, 0) for sev in SEVERITY_ORDER}
