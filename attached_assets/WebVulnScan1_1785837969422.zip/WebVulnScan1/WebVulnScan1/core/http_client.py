"""
http_client.py
A requests.Session wrapper that enforces a delay between every outgoing
request (rate limiting), applies a timeout, and retries transient errors.
"""
import time
import requests
from requests.adapters import HTTPAdapter
try:
    from urllib3.util.retry import Retry
except ImportError:
    from requests.packages.urllib3.util.retry import Retry

DEFAULT_USER_AGENT = "WebVulnScannerGUI/1.0 (+educational-security-tool; authorized-testing-only)"


class RateLimitedClient:
    def __init__(self, delay=1.0, timeout=10, verify_ssl=True, cookie=None):
        self.delay = max(0.0, delay)
        self.timeout = timeout
        self._last_request_time = 0.0
        self.request_count = 0

        self.session = requests.Session()
        self.session.headers.update({"User-Agent": DEFAULT_USER_AGENT, "Accept": "*/*"})
        self.session.verify = verify_ssl
        if cookie:
            self.session.headers.update({"Cookie": cookie})

        retry = Retry(total=2, backoff_factor=0.5, status_forcelist=[502, 503, 504],
                      allowed_methods=["GET", "POST"])
        adapter = HTTPAdapter(max_retries=retry)
        self.session.mount("http://", adapter)
        self.session.mount("https://", adapter)

    def _throttle(self):
        if self.delay <= 0:
            return
        elapsed = time.time() - self._last_request_time
        wait = self.delay - elapsed
        if wait > 0:
            time.sleep(wait)

    def _record(self):
        self._last_request_time = time.time()
        self.request_count += 1

    def get(self, url, params=None, **kwargs):
        self._throttle()
        try:
            return self.session.get(url, params=params, timeout=self.timeout, **kwargs)
        except requests.RequestException:
            return None
        finally:
            self._record()

    def post(self, url, data=None, **kwargs):
        self._throttle()
        try:
            return self.session.post(url, data=data, timeout=self.timeout, **kwargs)
        except requests.RequestException:
            return None
        finally:
            self._record()
