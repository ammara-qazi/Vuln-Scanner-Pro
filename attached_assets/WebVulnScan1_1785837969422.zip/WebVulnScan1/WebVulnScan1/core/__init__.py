"""Core scanning engine: HTTP client, crawler, and vulnerability checks."""
__version__ = "1.0.0"
