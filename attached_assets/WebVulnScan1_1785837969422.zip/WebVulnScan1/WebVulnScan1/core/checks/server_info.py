"""server_info.py - flags info-disclosing headers and verbose error signatures."""
import re

INFO_HEADERS = ["Server", "X-Powered-By", "X-AspNet-Version", "X-AspNetMvc-Version", "X-Generator"]
VERSION_PATTERN = re.compile(r"\d+\.\d+")

ERROR_SIGNATURES = [
    ("PHP Warning", "PHP"), ("PHP Fatal error", "PHP"), ("Stack trace:", "Generic"),
    ("at System.", ".NET"), ("Microsoft OLE DB Provider", ".NET/SQL Server"),
    ("Traceback (most recent call last)", "Python"), ("Django Version", "Django"),
    ("Whitelabel Error Page", "Spring Boot"),
]


def run(client, url):
    findings = []
    resp = client.get(url)
    if resp is None:
        return findings

    for header in INFO_HEADERS:
        value = resp.headers.get(header)
        if not value:
            continue
        has_version = bool(VERSION_PATTERN.search(value))
        findings.append({
            "type": "Server Information Disclosure",
            "severity": "Medium" if has_version else "Low", "url": url,
            "location": f"HTTP header: {header}",
            "description": f"'{header}' header discloses server/software details, helping "
                           "attackers fingerprint known vulnerabilities.",
            "evidence": f"{header}: {value}",
            "recommendation": f"Suppress or generalize the '{header}' header.",
        })

    text = resp.text if hasattr(resp, "text") else ""
    for sig, tech in ERROR_SIGNATURES:
        if sig in text:
            findings.append({
                "type": "Verbose Error / Stack Trace Disclosure", "severity": "Medium", "url": url,
                "location": "Response body",
                "description": f"Response appears to contain a {tech} error/stack trace, "
                               "potentially leaking file paths or internals.",
                "evidence": f"Matched signature: '{sig}'",
                "recommendation": "Disable debug/verbose error output in production.",
            })
    return findings
