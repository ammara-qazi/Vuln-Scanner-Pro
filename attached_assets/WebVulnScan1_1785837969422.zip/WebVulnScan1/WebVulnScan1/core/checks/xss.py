"""xss.py - reflected XSS detection via unique marker payload reflection."""
import uuid
from urllib.parse import urlparse, parse_qs, urlencode, urlunparse

TEMPLATE_A = "<script>alert('WVS_{token}')</script>"
TEMPLATE_B = "\"'><svg onload=alert('WVS_{token}')>"
TEMPLATE_C = "javascript:alert('WVS_{token}')"
TEMPLATE_D = "<img src=x onerror=alert('WVS_{token}')>"


def _payloads():
    token = uuid.uuid4().hex[:8]
    return [
        TEMPLATE_A.format(token=token),
        TEMPLATE_B.format(token=token),
        TEMPLATE_C.format(token=token),
        TEMPLATE_D.format(token=token),
    ]


def _reflected(body, payload):
    return payload in body


def _test_params(client, page):
    findings = []
    if not page.url_params:
        return findings
    parsed = urlparse(page.url)
    query = parse_qs(parsed.query)

    for param in page.url_params:
        for payload in _payloads():
            test_query = {k: v[0] for k, v in query.items()}
            test_query[param] = payload
            new_url = urlunparse(parsed._replace(query=urlencode(test_query)))
            resp = client.get(new_url)
            if resp is not None and _reflected(resp.text, payload):
                findings.append({
                    "type": "Reflected Cross-Site Scripting (XSS)", "severity": "High",
                    "url": page.url, "location": f"GET parameter '{param}'",
                    "description": f"Parameter '{param}' is reflected without HTML-encoding.",
                    "evidence": f"Payload reflected verbatim: {payload}",
                    "recommendation": "HTML-encode all user-controlled output.",
                    "test_url": new_url,
                })
                break
    return findings


def _test_forms(client, page):
    findings = []
    for form in page.forms:
        action, method, inputs = form["action"], form["method"], form["inputs"]
        for target in inputs:
            for payload in _payloads():
                data = {f["name"]: "test" for f in inputs}
                data[target["name"]] = payload
                resp = client.post(action, data=data) if method == "post" else client.get(action, params=data)
                if resp is not None and _reflected(resp.text, payload):
                    findings.append({
                        "type": "Reflected/Stored Cross-Site Scripting (XSS)", "severity": "High",
                        "url": page.url,
                        "location": f"Form field '{target['name']}' (action: {action}, method: {method.upper()})",
                        "description": f"Form field '{target['name']}' is reflected without HTML-encoding.",
                        "evidence": f"Payload reflected verbatim: {payload}",
                        "recommendation": "HTML-encode output; validate/sanitize on input too.",
                    })
                    break
    return findings


def run(client, pages, progress_cb=None):
    findings = []
    for page in pages:
        if progress_cb:
            progress_cb(f"Testing XSS on {page.url}")
        findings.extend(_test_params(client, page))
        findings.extend(_test_forms(client, page))
    return findings
