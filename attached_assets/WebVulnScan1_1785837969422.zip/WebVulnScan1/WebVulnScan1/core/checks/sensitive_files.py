"""sensitive_files.py - checks for sensitive files and directories."""

SENSITIVE_PATHS = [
    (".env", "Environment file containing secrets", "Critical"),
    (".git/config", "Git configuration file", "High"),
    (".git/head", "Git HEAD file", "High"),
    ("phpinfo.php", "PHP configuration information", "Medium"),
    ("config.php.bak", "Backup of configuration file", "High"),
    (".htaccess", "Apache configuration file", "Medium"),
    (".ssh/id_rsa", "Private SSH key", "Critical"),
    ("backup.sql", "Database backup file", "High"),
    ("dump.sql", "Database backup file", "High"),
    ("server-status", "Apache server status page", "Low"),
    ("wp-config.php", "WordPress configuration file", "High"),
]

def run(client, target):
    findings = []
    base_url = target.rstrip("/") + "/"
    
    for path, desc, severity in SENSITIVE_PATHS:
        url = base_url + path
        resp = client.get(url)
        
        if resp and resp.status_code == 200:
            # Check for false positives (e.g., custom 404 pages that return 200)
            if len(resp.text) > 0 and "404" not in resp.text.lower() and "not found" not in resp.text.lower():
                findings.append({
                    "type": "Sensitive File Disclosure",
                    "severity": severity,
                    "url": url,
                    "location": f"Path: /{path}",
                    "description": f"The sensitive file '{path}' was found. {desc}.",
                    "evidence": f"HTTP 200 OK at {url}",
                    "recommendation": "Restrict access to sensitive files or remove them from the web root.",
                })
    return findings
