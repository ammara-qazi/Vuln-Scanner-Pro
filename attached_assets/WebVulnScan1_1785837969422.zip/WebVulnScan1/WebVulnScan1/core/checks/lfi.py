"""lfi.py - checks for Local File Inclusion (LFI) vulnerabilities."""
from urllib.parse import urlparse, parse_qs, urlencode, urlunparse

LFI_PAYLOADS = [
    ("../../etc/passwd", "root:x:0:0:"),
    ("..\\..\\..\\..\\..\\..\\..\\..\\..\\..\\windows\\win.ini", "[extensions]"),
    ("/etc/passwd", "root:x:0:0:"),
]

def run(client, pages, progress_cb=None):
    findings = []
    for page in pages:
        if not page.url_params:
            continue
            
        if progress_cb:
            progress_cb(f"Testing LFI on {page.url}")
            
        parsed = urlparse(page.url)
        query = parse_qs(parsed.query)
        
        for param in page.url_params:
            for payload, signature in LFI_PAYLOADS:
                tq = {k: v[0] for k, v in query.items()}
                tq[param] = payload
                url = urlunparse(parsed._replace(query=urlencode(tq)))
                
                resp = client.get(url)
                if resp and signature in resp.text:
                    findings.append({
                        "type": "Local File Inclusion (LFI)",
                        "severity": "Critical",
                        "url": page.url,
                        "location": f"GET parameter '{param}'",
                        "description": f"The parameter '{param}' is vulnerable to LFI, allowing access to system files.",
                        "evidence": f"Found signature '{signature}' in response.",
                        "recommendation": "Use a whitelist for file inclusion or avoid including files based on user input.",
                        "test_url": url,
                    })
                    break
    return findings
