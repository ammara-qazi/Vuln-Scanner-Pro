"""open_redirect.py - checks for open redirect vulnerabilities."""
from urllib.parse import urlparse, parse_qs, urlencode, urlunparse

REDIRECT_PAYLOADS = [
    "https://google.com",
    "//google.com",
    "https:google.com",
]

def run(client, pages, progress_cb=None):
    findings = []
    for page in pages:
        if progress_cb:
            progress_cb(f"Testing Open Redirect on {page.url}")
        
        parsed = urlparse(page.url)
        query = parse_qs(parsed.query)
        
        for param in page.url_params:
            for payload in REDIRECT_PAYLOADS:
                tq = {k: v[0] for k, v in query.items()}
                tq[param] = payload
                url = urlunparse(parsed._replace(query=urlencode(tq)))
                
                # We don't want the client to automatically follow redirects here
                # so we can check the Location header.
                # However, RateLimitedClient uses requests.Session which follows by default.
                # We'll use allow_redirects=False.
                resp = client.session.get(url, timeout=client.timeout, allow_redirects=False)
                
                if resp.status_code in (301, 302, 303, 307, 308):
                    location = resp.headers.get("Location", "")
                    if location.startswith("https://google.com") or location.startswith("//google.com"):
                        findings.append({
                            "type": "Open Redirect",
                            "severity": "Medium",
                            "url": page.url,
                            "location": f"GET parameter '{param}'",
                            "description": f"The application redirects to an external URL based on the '{param}' parameter.",
                            "evidence": f"Redirected to: {location}",
                            "recommendation": "Validate redirect targets against a whitelist or use relative paths.",
                        })
                        break
    return findings
