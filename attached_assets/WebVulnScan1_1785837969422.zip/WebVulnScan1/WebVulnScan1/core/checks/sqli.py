"""sqli.py - error-based + boolean-based (blind) SQL injection detection."""
from urllib.parse import urlparse, parse_qs, urlencode, urlunparse

ERROR_PAYLOADS = ["'", "\"", "' OR '1'='1", "1' AND '1'='2"]
TRUE_PAYLOAD, FALSE_PAYLOAD = "' OR '1'='1", "' OR '1'='2"

DB_ERROR_SIGNATURES = [
    "you have an error in your sql syntax", "warning: mysql",
    "unclosed quotation mark after the character string",
    "quoted string not properly terminated", "sqlite3.operationalerror", "sqlite_error",
    "pg_query()", "postgresql query failed", "ora-01756",
    "supplied argument is not a valid mysql", "syntax error at or near",
]


def _find_sig(body):
    lower = body.lower()
    for sig in DB_ERROR_SIGNATURES:
        if sig in lower:
            return sig
    return None


def _submit(client, method, action, data):
    return client.post(action, data=data) if method == "post" else client.get(action, params=data)


def _test_params(client, page):
    findings = []
    if not page.url_params:
        return findings
    parsed = urlparse(page.url)
    query = parse_qs(parsed.query)

    for param in page.url_params:
        for payload in ERROR_PAYLOADS:
            tq = {k: v[0] for k, v in query.items()}
            tq[param] = payload
            url = urlunparse(parsed._replace(query=urlencode(tq)))
            resp = client.get(url)
            if resp is None:
                continue
            sig = _find_sig(resp.text)
            if sig:
                findings.append({
                    "type": "SQL Injection (Error-Based)", "severity": "Critical", "url": page.url,
                    "location": f"GET parameter '{param}'",
                    "description": f"Injecting '{payload}' into '{param}' produced a DB error.",
                    "evidence": f"Detected DB error signature: '{sig}'",
                    "recommendation": "Use parameterized queries / prepared statements.",
                    "test_url": url,
                })
                break
        else:
            tq_t = {k: v[0] for k, v in query.items()}; tq_t[param] = TRUE_PAYLOAD
            tq_f = {k: v[0] for k, v in query.items()}; tq_f[param] = FALSE_PAYLOAD
            r_t = client.get(urlunparse(parsed._replace(query=urlencode(tq_t))))
            r_f = client.get(urlunparse(parsed._replace(query=urlencode(tq_f))))
            if r_t is not None and r_f is not None and abs(len(r_t.text) - len(r_f.text)) > 20:
                findings.append({
                    "type": "SQL Injection (Boolean-Based / Blind)", "severity": "Critical",
                    "url": page.url, "location": f"GET parameter '{param}'",
                    "description": f"Response length differs between TRUE/FALSE payloads for '{param}'.",
                    "evidence": f"TRUE -> {len(r_t.text)}b, FALSE -> {len(r_f.text)}b",
                    "recommendation": "Use parameterized queries / prepared statements.",
                })
    return findings


def _test_forms(client, page):
    findings = []
    for form in page.forms:
        action, method, inputs = form["action"], form["method"], form["inputs"]
        for target in inputs:
            hit = None
            for payload in ERROR_PAYLOADS:
                data = {f["name"]: "1" for f in inputs}
                data[target["name"]] = payload
                resp = _submit(client, method, action, data)
                if resp is None:
                    continue
                sig = _find_sig(resp.text)
                if sig:
                    hit = {
                        "type": "SQL Injection (Error-Based)", "severity": "Critical", "url": action,
                        "location": f"Field '{target['name']}' (method: {method.upper()})",
                        "description": f"Injecting '{payload}' into '{target['name']}' produced a DB error.",
                        "evidence": f"Detected DB error signature: '{sig}'",
                        "recommendation": "Use parameterized queries / prepared statements.",
                    }
                    break
            if hit:
                findings.append(hit)
                continue

            base = {f["name"]: "1" for f in inputs}
            td = dict(base); td[target["name"]] = TRUE_PAYLOAD
            fd = dict(base); fd[target["name"]] = FALSE_PAYLOAD
            r_t = _submit(client, method, action, td)
            r_f = _submit(client, method, action, fd)
            if r_t is not None and r_f is not None and abs(len(r_t.text) - len(r_f.text)) > 20:
                findings.append({
                    "type": "SQL Injection (Boolean-Based / Blind)", "severity": "Critical", "url": action,
                    "location": f"Field '{target['name']}' (method: {method.upper()})",
                    "description": f"Response length differs between TRUE/FALSE payloads for '{target['name']}'.",
                    "evidence": f"TRUE -> {len(r_t.text)}b, FALSE -> {len(r_f.text)}b",
                    "recommendation": "Use parameterized queries / prepared statements.",
                })
    return findings


def run(client, pages, progress_cb=None):
    findings = []
    for page in pages:
        if progress_cb:
            progress_cb(f"Testing SQLi on {page.url}")
        findings.extend(_test_params(client, page))
        findings.extend(_test_forms(client, page))
    return findings
