"""directory_listing.py - checks for directory listing disclosure."""

DIR_LISTING_SIGNATURES = [
    "<title>Index of /",
    "<h1>Index of /",
    "Parent Directory</a>",
    "Last modified</a>",
]

def run(client, target):
    findings = []
    # Check common directories
    dirs = ["/images/", "/uploads/", "/css/", "/js/", "/backup/", "/conf/"]
    
    for d in dirs:
        url = target.rstrip("/") + d
        resp = client.get(url)
        if resp and resp.status_code == 200:
            body = resp.text
            for sig in DIR_LISTING_SIGNATURES:
                if sig in body:
                    findings.append({
                        "type": "Directory Listing Enabled",
                        "severity": "Medium",
                        "url": url,
                        "location": "Server Configuration",
                        "description": f"The directory '{d}' has directory listing enabled, exposing its contents.",
                        "evidence": f"Found signature: '{sig}'",
                        "recommendation": "Disable directory listing in the server configuration (e.g., 'Options -Indexes' in Apache).",
                    })
                    break
    return findings
