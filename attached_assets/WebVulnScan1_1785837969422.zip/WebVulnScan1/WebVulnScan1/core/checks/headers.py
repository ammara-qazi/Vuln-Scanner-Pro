"""security_headers.py - checks for missing common security headers + cookie flags."""

CHECKED_HEADERS = {
    "Content-Security-Policy": ("Medium", "No CSP header found. CSP restricts which script/style "
                                "sources the browser will execute, mitigating XSS impact."),
    "X-Frame-Options": ("Medium", "No X-Frame-Options header found. Page may be vulnerable to "
                        "clickjacking (embedding in a hidden iframe)."),
    "Strict-Transport-Security": ("Medium", "No HSTS header found. Users may be downgraded to "
                                 "plain HTTP and exposed to MITM attacks."),
    "X-Content-Type-Options": ("Low", "No X-Content-Type-Options header found. Browsers may "
                               "MIME-sniff responses, enabling content-type confusion attacks."),
    "Referrer-Policy": ("Low", "No Referrer-Policy header found. Full referrer URLs may leak to "
                       "third parties."),
    "Permissions-Policy": ("Low", "No Permissions-Policy header found. Powerful browser features "
                          "are not explicitly restricted."),
}


def run(client, url):
    findings = []
    resp = client.get(url)
    if resp is None:
        return findings
    headers = resp.headers

    for name, (severity, desc) in CHECKED_HEADERS.items():
        if name not in headers:
            findings.append({
                "type": "Missing Security Header", "severity": severity, "url": url,
                "location": name, "description": desc,
                "evidence": f"Response headers did not contain '{name}'.",
                "recommendation": f"Add the '{name}' header with an appropriate policy.",
            })

    set_cookie = headers.get("Set-Cookie", "")
    if set_cookie:
        lower = set_cookie.lower()
        for flag, sev, desc in [
            ("secure", "Low", "Cookie missing 'Secure' flag, may be sent over plain HTTP."),
            ("httponly", "Low", "Cookie missing 'HttpOnly' flag, readable via JavaScript."),
            ("samesite", "Low", "Cookie missing 'SameSite' attribute, weaker CSRF protection."),
        ]:
            if flag not in lower:
                findings.append({
                    "type": "Insecure Cookie", "severity": sev, "url": url,
                    "location": "Set-Cookie header", "description": desc,
                    "evidence": set_cookie[:200],
                    "recommendation": f"Set the '{flag}' attribute on cookies.",
                })
    return findings
