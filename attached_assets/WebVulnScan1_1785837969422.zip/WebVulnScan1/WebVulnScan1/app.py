#!/usr/bin/env python3
"""
app.py - Flask backend for WebVulnScanner GUI.

Run with:  python app.py
Then open: http://127.0.0.1:5000
"""
import os
import time
import uuid
import threading
import logging
from urllib.parse import urlparse

from flask import Flask, request, jsonify, render_template, send_file, abort

from core.http_client import RateLimitedClient
from core.crawler import Crawler
from core.checks import headers as headers_check
from core.checks import server_info as server_info_check
from core.checks import xss as xss_check
from core.checks import sqli as sqli_check
from core.checks import open_redirect as open_redirect_check
from core.checks import directory_listing as directory_listing_check
from core.checks import sensitive_files as sensitive_files_check
from core.checks import lfi as lfi_check
from core import report_writer

logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(message)s")
logger = logging.getLogger("webvulnscanner")

try:
    import docx  # noqa: F401  (python-docx package; import name differs from pip name)
except ImportError:
    logger.warning(
        "python-docx is not installed - DOCX report downloads will fail. "
        "Run: pip install -r requirements.txt"
    )

APP_DIR = os.path.dirname(os.path.abspath(__file__))
REPORTS_DIR = os.path.join(APP_DIR, "reports")
os.makedirs(REPORTS_DIR, exist_ok=True)

app = Flask(__name__)

# In-memory job store. Fine for a single-user local tool; not for multi-user production.
JOBS = {}
JOBS_LOCK = threading.Lock()

CHECK_RUNNERS = {
    "headers": lambda client, target, pages, log: headers_check.run(client, target),
    "server-info": lambda client, target, pages, log: server_info_check.run(client, target),
    "directory-listing": lambda client, target, pages, log: directory_listing_check.run(client, target),
    "sensitive-files": lambda client, target, pages, log: sensitive_files_check.run(client, target),
    "open-redirect": lambda client, target, pages, log: open_redirect_check.run(client, pages, progress_cb=log),
    "lfi": lambda client, target, pages, log: lfi_check.run(client, pages, progress_cb=log),
    "xss": lambda client, target, pages, log: xss_check.run(client, pages, progress_cb=log),
    "sqli": lambda client, target, pages, log: sqli_check.run(client, pages, progress_cb=log),
}
CHECK_LABELS = {
    "headers": "Missing Security Headers",
    "server-info": "Server Information Disclosure",
    "directory-listing": "Directory Listing Disclosure",
    "sensitive-files": "Sensitive File Disclosure",
    "open-redirect": "Open Redirect",
    "lfi": "Local File Inclusion (LFI)",
    "xss": "Reflected Cross-Site Scripting (XSS)",
    "sqli": "SQL Injection",
}


def _validate_target(url):
    """Basic sanity checks on the submitted target URL."""
    parsed = urlparse(url)
    if parsed.scheme not in ("http", "https"):
        return "URL must start with http:// or https://"
    if not parsed.netloc:
        return "URL must include a host, e.g. http://localhost:3000/"
    return None


def _run_job(job_id, target, delay, max_depth, max_pages, checks, cookie, timeout):
    def log(msg):
        with JOBS_LOCK:
            JOBS[job_id]["log"].append(msg)
            JOBS[job_id]["stage"] = msg
        logger.info("[%s] %s", job_id, msg)

    try:
        log(f"Starting scan of {target}")
        client = RateLimitedClient(delay=delay, timeout=timeout, cookie=cookie)

        log("Crawling target (discovering pages, forms, parameters)...")
        crawler = Crawler(client, target, max_depth=max_depth, max_pages=max_pages, progress_cb=log)
        pages = crawler.crawl()
        log(f"Crawl complete: {len(pages)} page(s) discovered")

        all_findings = []
        for check_id in checks:
            if check_id not in CHECK_RUNNERS:
                continue
            log(f"Running check: {CHECK_LABELS.get(check_id, check_id)}...")
            result = CHECK_RUNNERS[check_id](client, target, pages, log)
            all_findings.extend(result)
            log(f"{CHECK_LABELS.get(check_id, check_id)} complete: {len(result)} finding(s)")

        stats = {
            "pages_crawled": len(pages),
            "requests_sent": client.request_count,
            "checks_run": checks,
        }

        with JOBS_LOCK:
            JOBS[job_id]["findings"] = all_findings
            JOBS[job_id]["stats"] = stats
            JOBS[job_id]["severity_summary"] = report_writer.severity_summary(all_findings)
            JOBS[job_id]["status"] = "done"
            JOBS[job_id]["finished_at"] = time.time()
        log(f"Scan complete: {len(all_findings)} finding(s)")

    except Exception as exc:  # noqa: BLE001 - surface any failure to the UI instead of hanging
        logger.exception("Scan job %s failed", job_id)
        with JOBS_LOCK:
            JOBS[job_id]["status"] = "error"
            JOBS[job_id]["error"] = str(exc)
            JOBS[job_id]["log"].append(f"ERROR: {exc}")


@app.route("/")
def index():
    return render_template("index.html")


@app.route("/api/scan", methods=["POST"])
def start_scan():
    data = request.get_json(force=True, silent=True) or {}

    target = (data.get("target") or "").strip()
    confirmed = bool(data.get("confirmed"))

    if not target:
        return jsonify({"error": "Target URL is required."}), 400
    err = _validate_target(target)
    if err:
        return jsonify({"error": err}), 400
    if not confirmed:
        return jsonify({"error": "You must confirm you own this target or have explicit "
                                 "permission to test it."}), 400

    delay = float(data.get("delay", 1.0))
    max_depth = int(data.get("max_depth", 2))
    max_pages = int(data.get("max_pages", 30))
    timeout = int(data.get("timeout", 10))
    checks = data.get("checks") or list(CHECK_RUNNERS.keys())
    cookie = (data.get("cookie") or "").strip() or None

    # Sane bounds so the GUI can't be used to accidentally launch a huge crawl
    delay = max(0.0, min(delay, 10.0))
    max_depth = max(0, min(max_depth, 5))
    max_pages = max(1, min(max_pages, 100))
    timeout = max(1, min(timeout, 30))

    job_id = uuid.uuid4().hex[:12]
    with JOBS_LOCK:
        JOBS[job_id] = {
            "target": target, "status": "running", "log": [], "stage": "Queued",
            "findings": None, "stats": None, "severity_summary": None,
            "created_at": time.time(), "error": None,
        }

    thread = threading.Thread(
        target=_run_job,
        args=(job_id, target, delay, max_depth, max_pages, checks, cookie, timeout),
        daemon=True,
    )
    thread.start()

    return jsonify({"job_id": job_id})


@app.route("/api/status/<job_id>")
def job_status(job_id):
    with JOBS_LOCK:
        job = JOBS.get(job_id)
        if not job:
            return jsonify({"error": "Unknown job id"}), 404
        return jsonify({
            "status": job["status"],
            "stage": job["stage"],
            "log_tail": job["log"][-8:],
            "log_count": len(job["log"]),
            "error": job["error"],
        })


@app.route("/api/result/<job_id>")
def job_result(job_id):
    with JOBS_LOCK:
        job = JOBS.get(job_id)
        if not job:
            return jsonify({"error": "Unknown job id"}), 404
        if job["status"] != "done":
            return jsonify({"error": "Job not finished yet", "status": job["status"]}), 409
        return jsonify({
            "target": job["target"],
            "stats": job["stats"],
            "severity_summary": job["severity_summary"],
            "findings": report_writer.sort_findings(job["findings"]),
        })


@app.route("/api/report/<job_id>/<fmt>")
def download_report(job_id, fmt):
    if fmt not in ("json", "txt", "html", "docx"):
        abort(400)
    with JOBS_LOCK:
        job = JOBS.get(job_id)
        if not job or job["status"] != "done":
            abort(404)
        target, findings, stats = job["target"], job["findings"], job["stats"]

    path = os.path.join(REPORTS_DIR, f"{job_id}.{fmt}")
    if not os.path.exists(path):
        if fmt == "json":
            report_writer.write_json(path, target, findings, stats)
        elif fmt == "txt":
            report_writer.write_txt(path, target, findings, stats)
        elif fmt == "html":
            report_writer.write_html(path, target, findings, stats)
        elif fmt == "docx":
            try:
                report_writer.write_docx(path, target, findings, stats)
            except Exception as e:
                logger.error(f"Failed to generate Word report: {e}")
                return jsonify({"error": f"Failed to generate Word report: {str(e)}"}), 500

    return send_file(path, as_attachment=True,
                     download_name=f"webvulnscanner_report_{job_id}.{fmt}")


if __name__ == "__main__":
    print("\n  WebVulnScanner GUI running at: http://127.0.0.1:5000\n")
    app.run(host="127.0.0.1", port=5000, debug=False)
