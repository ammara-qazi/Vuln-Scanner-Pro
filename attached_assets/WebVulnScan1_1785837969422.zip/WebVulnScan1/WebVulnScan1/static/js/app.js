const STAGE_ORDER = ["queue", "crawl", "headers", "server-info", "directory-listing", "sensitive-files", "open-redirect", "lfi", "xss", "sqli", "done"];

const advancedToggle = document.getElementById("advancedToggle");
const advancedBox = document.getElementById("advancedBox");
advancedToggle.addEventListener("click", () => {
  advancedToggle.classList.toggle("open");
  advancedBox.classList.toggle("open");
});

const form = document.getElementById("scanForm");
const runBtn = document.getElementById("runBtn");
const formError = document.getElementById("formError");
const railPanel = document.getElementById("railPanel");
const resultsPanel = document.getElementById("resultsPanel");
const logFeed = document.getElementById("logFeed");
const currentStageText = document.getElementById("currentStageText");

let pollTimer = null;

function setStage(stageKey) {
  const idx = STAGE_ORDER.indexOf(stageKey);
  document.querySelectorAll(".stage").forEach((el, i) => {
    const elIdx = STAGE_ORDER.indexOf(el.dataset.stage);
    el.classList.remove("active", "complete");
    if (elIdx < idx) el.classList.add("complete");
    else if (elIdx === idx) el.classList.add("active");
  });
  document.querySelectorAll(".rail-line").forEach((line, i) => {
    line.classList.toggle("filled", i < idx);
  });
}

function guessStageFromText(text) {
  const t = text.toLowerCase();
  if (t.includes("crawl")) return "crawl";
  if (t.includes("missing security headers")) return "headers";
  if (t.includes("server information")) return "server-info";
  if (t.includes("directory listing")) return "directory-listing";
  if (t.includes("sensitive file")) return "sensitive-files";
  if (t.includes("open redirect")) return "open-redirect";
  if (t.includes("lfi") || t.includes("local file inclusion")) return "lfi";
  if (t.includes("xss")) return "xss";
  if (t.includes("sqli") || t.includes("sql injection")) return "sqli";
  if (t.includes("scan complete")) return "done";
  return "queue";
}

form.addEventListener("submit", async (e) => {
  e.preventDefault();
  formError.textContent = "";

  const target = document.getElementById("target").value.trim();
  const confirmed = document.getElementById("confirmOwn").checked;

  if (!confirmed) {
    formError.textContent = "Please confirm you're authorized to scan this target.";
    return;
  }

  const checks = Array.from(document.querySelectorAll("#checksRow input:checked")).map(c => c.value);
  if (checks.length === 0) {
    formError.textContent = "Select at least one check to run.";
    return;
  }

  const payload = {
    target,
    confirmed,
    delay: parseFloat(document.getElementById("delay").value || "1.0"),
    max_depth: parseInt(document.getElementById("maxDepth").value || "2", 10),
    max_pages: parseInt(document.getElementById("maxPages").value || "30", 10),
    cookie: document.getElementById("cookie").value.trim(),
    checks,
  };

  runBtn.disabled = true;
  runBtn.querySelector(".run-btn-label").textContent = "Scanning…";
  resultsPanel.classList.add("hidden");
  railPanel.classList.remove("hidden");
  logFeed.innerHTML = "";
  setStage("queue");
  currentStageText.textContent = "Starting…";
  railPanel.scrollIntoView({ behavior: "smooth", block: "start" });

  try {
    const res = await fetch("/api/scan", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload),
    });
    const data = await res.json();
    if (!res.ok) {
      formError.textContent = data.error || "Failed to start scan.";
      resetRunButton();
      railPanel.classList.add("hidden");
      return;
    }
    pollStatus(data.job_id);
  } catch (err) {
    formError.textContent = "Could not reach the scanner backend.";
    resetRunButton();
  }
});

function resetRunButton() {
  runBtn.disabled = false;
  runBtn.querySelector(".run-btn-label").textContent = "Run scan";
}

function pollStatus(jobId) {
  pollTimer = setInterval(async () => {
    try {
      const res = await fetch(`/api/status/${jobId}`);
      const data = await res.json();
      if (!res.ok) {
        clearInterval(pollTimer);
        formError.textContent = data.error || "Job not found.";
        resetRunButton();
        return;
      }

      currentStageText.textContent = data.stage || "Working…";
      setStage(guessStageFromText(data.stage || ""));
      logFeed.innerHTML = (data.log_tail || []).map(l => `<div>${escapeHtml(l)}</div>`).join("");
      logFeed.scrollTop = logFeed.scrollHeight;

      if (data.status === "done") {
        clearInterval(pollTimer);
        setStage("done");
        currentStageText.textContent = "Scan complete.";
        await loadResults(jobId);
        resetRunButton();
      } else if (data.status === "error") {
        clearInterval(pollTimer);
        formError.textContent = "Scan failed: " + (data.error || "unknown error");
        resetRunButton();
      }
    } catch (err) {
      // transient network hiccup while polling; keep trying
    }
  }, 1200);
}

async function loadResults(jobId) {
  const res = await fetch(`/api/result/${jobId}`);
  const data = await res.json();
  if (!res.ok) return;

  document.getElementById("resultTarget").textContent = data.target;
  wireDownload("dlJson", jobId, "json");
  wireDownload("dlTxt", jobId, "txt");
  wireDownload("dlHtml", jobId, "html");
  wireDownload("dlDocx", jobId, "docx");

  const statRow = document.getElementById("statRow");
  statRow.innerHTML = `
    <div class="stat"><strong>${data.stats.pages_crawled}</strong>Pages crawled</div>
    <div class="stat"><strong>${data.stats.requests_sent}</strong>Requests sent</div>
    <div class="stat"><strong>${data.findings.length}</strong>Total findings</div>
  `;

  const sevRow = document.getElementById("severityRow");
  sevRow.innerHTML = Object.entries(data.severity_summary)
    .map(([sev, count]) => `<div class="pill ${sev}">${sev}: ${count}</div>`).join("");

  const list = document.getElementById("findingsList");
  if (data.findings.length === 0) {
    list.innerHTML = `<div class="empty-state">
      <h3>No issues detected</h3>
      <p>None of the checks you selected found a match. This doesn't guarantee the app is secure —
      it only reflects the checks that ran.</p></div>`;
  } else {
    list.innerHTML = data.findings.map((f, i) => `
      <div class="finding ${f.severity}">
        <div class="finding-title">
          <h3>${i + 1}. ${escapeHtml(f.type)}</h3>
          <span class="badge ${f.severity}">${f.severity}</span>
        </div>
        <div class="f-row"><span class="label">URL</span>${escapeHtml(f.url)}</div>
        <div class="f-row"><span class="label">Location</span>${escapeHtml(f.location)}</div>
        <div class="f-row"><span class="label">Description</span>${escapeHtml(f.description)}</div>
        <div class="f-row"><span class="label">Recommendation</span>${escapeHtml(f.recommendation || "n/a")}</div>
        <div class="f-evidence">${escapeHtml(f.evidence || "n/a")}</div>
      </div>
    `).join("");
  }

  resultsPanel.classList.remove("hidden");
  resultsPanel.scrollIntoView({ behavior: "smooth", block: "start" });
}

function wireDownload(btnId, jobId, fmt) {
  const el = document.getElementById(btnId);
  el.href = "#";
  el.onclick = async (e) => {
    e.preventDefault();
    const originalLabel = el.textContent;
    el.textContent = "…";
    try {
      const res = await fetch(`/api/report/${jobId}/${fmt}`);
      const contentType = res.headers.get("Content-Type") || "";
      if (!res.ok || contentType.includes("application/json")) {
        // Server returned an error (e.g. missing python-docx dependency)
        let msg = `Failed to generate the ${fmt.toUpperCase()} report.`;
        try {
          const err = await res.json();
          if (err.error) msg = err.error;
        } catch (_) { /* not JSON, keep default message */ }
        alert(msg);
        return;
      }
      const blob = await res.blob();
      const url = URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = `webvulnscanner_report_${jobId}.${fmt}`;
      document.body.appendChild(a);
      a.click();
      a.remove();
      URL.revokeObjectURL(url);
    } catch (err) {
      alert(`Could not download the ${fmt.toUpperCase()} report: ${err.message}`);
    } finally {
      el.textContent = originalLabel;
    }
  };
}

function escapeHtml(str) {
  const div = document.createElement("div");
  div.textContent = str;
  return div.innerHTML;
}
